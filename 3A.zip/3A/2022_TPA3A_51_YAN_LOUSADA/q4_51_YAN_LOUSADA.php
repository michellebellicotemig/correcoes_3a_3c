<?php 

$num = rand($min = 1, $max = 3);

$cont1 = 0;
$cont2 = 0;
$cont3 = 0;

for($i = 0; $i < 10; $i++){

    $num = rand($min = 1, $max = 3);


    if($num == 1){
        $cont1++;
        echo "<br> O valor 1 foi mostrado  = $cont1 vezes <br><br><br>";
    }

    if($num == 2){
        $cont2++;
        echo "<br> O valor 2 foi mostrado  = $cont2 vezes <br><br><br>";
    }

   if($num == 3){
        $cont3++;
        echo "<br> O valor 3 foi mostrado  = $cont3 vezes <br><br><br>";
    }

}

?>
