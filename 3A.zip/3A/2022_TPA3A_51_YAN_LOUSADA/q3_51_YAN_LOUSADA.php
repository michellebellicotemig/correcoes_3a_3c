<?php 

$oi = 100;
$num = rand($min = 0, $max = 100);
$soma = $num + $num;

for($i = 0; $i < 10; $i++){
    $num = rand($min = 0, $max = 100);
    $soma = $num + $num;
    echo "soma dos valores e $soma";

    if($soma < 700){
        echo "<br> menor que 700 <br><br><br>";
    }
    elseif($soma > 700)
    {
        echo "<br> maior que 700 <br><br><br>";
    }
    elseif($soma ==700)
    {
        echo "<br> igual que 700 <br><br><br>";
    }

}
