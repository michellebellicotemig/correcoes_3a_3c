<?php
  header('Content-Type: text/html; charset=utf-8');

$numdez=0;
for($i=0; $i<9; $i++){
    $num = rand(0,10);
    
    $numdez = $num *10;
}

echo"<br>A soma dos valores iguais a 10 é :".$numdez;
if($numdez>=10){
    echo"<br>A soma dos valores é maior ou igual a 10.";
}else{
    echo"<br>A soma dos valores é menor do que 10.";
}







?>