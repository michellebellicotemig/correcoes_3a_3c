<?php
  header('Content-Type: text/html; charset=utf-8');
 


  
  
for($i=0; $i<100; $i++){
    $num = rand(0,11);
    switch($num){
        case 10:
            $num++;
        break;
    }
}

  echo"O número 10 apareceu ".$num." vezes.";
  


  ?>