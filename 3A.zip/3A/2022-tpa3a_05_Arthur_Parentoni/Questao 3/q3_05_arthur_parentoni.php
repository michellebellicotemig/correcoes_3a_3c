<?php

$cont = 0;
$numeroaleatorio = rand(0,100);
$soma = $numeroaleatorio + $numeroaleatorio;




if($soma>=700){

    echo("A soma dos valores e maior/igual a 700");
}

else
    echo ("A soma dos valores e menor que 700")

?>