<?php

$i1= 0;
$i2= 0;
$ii3= 0;

for($i = 0; $i <=10; $i++){
$vetor[$i] = rand(1,3);
if($vetor [$i] == 1){
$i1++;
}else if($vetor[$i] ==2){

$it2++;
}else{ 
$i3++; 
}
echo "Valor 1 sorteado" . $i1 . "vezes. <br>";
echo "Valor 2 sorteado" . $i2 . "vezes. <br>";
echo "Valor 3 sorteado" . $i3 . "vezes. <br>";
?>