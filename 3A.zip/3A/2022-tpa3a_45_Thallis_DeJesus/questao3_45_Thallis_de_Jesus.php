<?php
$aleatorio = rand(0,100);
$soma= 0;
$i = 0;

for($i = 0; $i <=10; $i++){
$vetor [$i] = rand(0, 100);

}

for($i = 0; $i <=10; $i++){
$soma = $soma + $vetor[$i];

}

if($soma < 700){
    echo("Resultado da soma é menor que 700") . "<br>"; 
} else{


}

if($soma = 328){
    echo("Resultado da soma é igual a 328");
} else{


}

$msg = "a some é igual a " . $soma;


?>