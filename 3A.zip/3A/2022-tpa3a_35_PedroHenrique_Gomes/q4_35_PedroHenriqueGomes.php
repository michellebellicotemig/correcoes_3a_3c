<?php

$cont = 0;
$menorNumero = 1;


while ($cont < 10){
$aleatorio = rand(1,3);

if($aleatorio<$menorNumero){
  $menorNumero=$aleatorio ;

}

  echo($aleatorio."<br>");
  $cont ++;
}


