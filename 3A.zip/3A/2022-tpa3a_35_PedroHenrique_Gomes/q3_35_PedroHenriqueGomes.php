<?php 
echo('Questao 03');
$i=0;
while ($cont < 10){
    $i = rand(0,100);
    
    if($i>0){
      $i=$i ;
    
    }
    
      echo($i."<br>");
      $cont ++;
    }


$soma= 0;
for ($i=0; $i <=100 ; $i++) { 
  if($i>0){
$soma = $soma + $i;
  }
}


if($soma>=700){
  echo ('<br/> A soma e maior ou igual a 700');
}else{
  echo ('<br/> A soma e menor que 700');
}
?>