<!DOCTYPE html>
<html>
<body>

<?php
header("Content-type: text/html; charset=utf-8");

$min = 0 ;
$max = 10;


  for($i =1; $i <= 100; $i++){
  echo  $i.$id;
}
?>
</body>
</html>