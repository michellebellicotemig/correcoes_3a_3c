<?php

//desclaraçãao de variável
$i = 0;
$cont1 = 0;
$cont2 = 0;
$cont3 = 0;

//estrutura de repetição em "for"
for($i = 0; $i < 10; $i++){
    $vetor[$i] = rand(1, 3);

    if($vetor[$i] == 1){
        $cont1++;
    } else if($vetor[$i] == 2){
        $cont2++;
    } else{
        $cont3++;
    }
}

//impressão do resultado
echo "O valor 1 foi sorteado " . $cont1 . " vezes. <br>";
echo "O valor 2 foi sorteado " . $cont2 . " vezes. <br>";
echo "O valor 3 foi sorteado " . $cont3 . " vezes. <br>";

?>