<?php

//desclaraçãao de variável
$soma = 0;
$i =0;
$msg = "";
$msgResult = "";
$msgNmr = "";

//for para gerar os números
for($i = 0; $i < 10; $i++){
    $vetor[$i] = rand(0, 100);
    $msgNmr = $vetor[$i];
    echo "Numero sorteado: " . $msgNmr . "<br>";
}

//for para somar os números
for($i = 0; $i < 10; $i++){
    $soma = $soma + $vetor[$i];
}

//exibição da mensagem
if($soma < 700){
    $msg = "O resultado da soma e menor que 700";
} else{
    $msg = "O resultado e maior que 700";
}
$msgResult = "<br> A soma deu " . $soma;
echo "<br>";
echo "$msg";
echo "$msgResult";


?>