<?php
//“Faça um laço de repetição que gere 100 números aleatórios de 0 a 10 realizando a contagem de todos os que forem iguais a 10”
//Variavel
$AcimaDe10 = 0;
//Calculo
for($i = 0; $i < 100; $i++){
    $num = rand(0,10);
    echo "$num, ";

    if($num == 10){
        $AcimaDe10++;
    }
}
//saida para usuario
    echo " <br>O valor 10 foi sorteado $AcimaDe10 vezes";
?>