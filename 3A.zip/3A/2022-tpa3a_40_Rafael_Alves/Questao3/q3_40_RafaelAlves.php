<?php
//“Faça um laço de repetição que gere 8 números aleatórios de 0 a 10 realizando a soma de todos os que forem iguais a 10 e informe:
//➔ Se a soma dos valores é maior ou igual a 10 ou
//➔ Se a soma dos valores é menor que 10”

//Variavel
$soma = 0;
$Msg = "";

//Calculo
for($i = 0; $i < 8; $i++){
    $Numeros = rand(0, 10);
    echo "$Numeros<br> ";
    if($Numeros == 10){
        $soma = $Numeros + $soma;
    }
    if($soma >= 10){
        $Msg = "A soma e maior ou igual a 10";
    
    }else {
        $Msg = "A soma e menor que 10";
    }
}
    
//Saida para Usuario
    echo "<br> A soma dos numeros iguais a 10 e: " .$soma;
    echo "<br> $Msg";
?>