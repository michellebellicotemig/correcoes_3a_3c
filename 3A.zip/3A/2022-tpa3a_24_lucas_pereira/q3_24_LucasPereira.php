<!DOCTYPE html>
<html>
<body>

<?php
$i = 0;
$soma;

while($i<=7){
    $num = rand(0,10);
    echo $num . ",";
    $i ++;
    
    if($num >= 10){
        echo $num . "A soma dos valores e maior ou igual a 10 e" . $soma;
    }else{
        echo $num . "A soma dos valores e menor que 10" . $soma;
    }
}
?>

</body>
</html>