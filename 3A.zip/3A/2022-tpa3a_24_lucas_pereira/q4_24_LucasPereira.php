<!DOCTYPE html>
<html>
<body>

<?php
$i = 0;
$vd = 0;

while($i<=100){
    $num = rand(0,10);
    echo $num . ",";
    $i ++;

    if($num <= 10 && $vd = 1){
    echo "O valor 10 foi sorteadado $vd vezes";
    }
}
$vd++
?>

</body>
</html>