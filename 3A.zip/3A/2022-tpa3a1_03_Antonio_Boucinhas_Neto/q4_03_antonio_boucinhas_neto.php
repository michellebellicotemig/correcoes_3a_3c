<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<?php 
$num = rand(1,3);
$cont = 0;
$soma = 0;
$um = 0;
$dois = 0;
$tres = 0;





while ($cont<10){
    
    $num = rand(1,3);
   
    echo"Numeros: $cont : $num<br>";
   
    
    if($num == 1){

    $um++;
    }
    elseif ($num ==2)
    {
 
    $dois++;
    }
    elseif ($num ==3)
    {
    $tres++;
    }
    $cont++;
}

echo"o numero um foi sorteado: $um<br>";
echo"o numero dois foi sorteado: $dois<br>";
echo"o numero tres foi sorteado: $tres<br>";




?>
    
</body>
</html>