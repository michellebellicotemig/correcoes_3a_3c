<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<?php 

$cont = 0;
$soma = 0;

while ($cont<10){
    
    $num = rand(0,100);
    $soma = $soma +$num;
    $cont++;
    echo"Numeros: $cont : $num<br>";
    
    
}

if ($soma >700){
    echo "A soma dos valores e maior que 700<br>";
    echo "Soma dos valores:$soma";
}
else{
    echo"A soma dos valores e menor que 700<br>";
    echo "Soma dos valores:$soma";

}






?>