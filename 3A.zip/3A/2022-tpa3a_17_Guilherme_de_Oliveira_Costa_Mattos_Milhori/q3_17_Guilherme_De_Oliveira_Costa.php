<?php
$num1 = 0;
$num2 = 0;
$num3 = 0;
$num4 = 0;
$num5 = 0;
$num6 = 0;
$num7 = 0;
$num8 = 0;
$num9 = 0;
$num10 = 0;
$som = 0;
$media = 0;


$num1 = random_int(0, 100);
$num2 = random_int(0, 100);
$num3 = random_int(0, 100);
$num4 = random_int(0, 100);
$num5 = random_int(0, 100);
$num6 = random_int(0, 100);
$num7 = random_int(0, 100);
$num8 = random_int(0, 100);
$num9 = random_int(0, 100);
$num10 = random_int(0, 100);


$som = $num1 + $num2 + $num3 + $num4 + $num5 + $num6+ $num7+ $num8+ $num9+ $num10;

$media = $som / 10;

if ($som >= 700 ) {
echo "soma maior ou igual 700";
}
else {
    echo "soma menor que 700";
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Sucesso</title>
</head>
<body>
<br><?php echo $num1 ?></br>
<br><?php echo $num2 ?></br>
<br><?php echo $num3 ?></br>
<br><?php echo $num4 ?></br>
<br><?php echo $num5 ?></br>
<br><?php echo $num6 ?></br>
<br><?php echo $num7 ?></br>
<br><?php echo $num8 ?></br>
<br><?php echo $num9 ?></br>
<br><?php echo $num10 ?></br>

<br>Soma dos numeros:<?php echo $som ?></br>
<br>Media dos numeros: <?php echo $media?></br>

</body>
</html>


