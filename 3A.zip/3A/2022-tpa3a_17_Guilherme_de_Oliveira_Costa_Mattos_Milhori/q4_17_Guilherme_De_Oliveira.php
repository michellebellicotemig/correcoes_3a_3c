<?php

$num1 = 0;
$num2 = 0;
$num3 = 0;
$num4 = 0;
$num5 = 0;
$num6 = 0;
$num7 = 0;
$num8 = 0;
$num9 = 0;
$num10 = 0;
$vzs1 = 0;
$vzs2 = 0;
$vzs3 = 0;



$num1 = random_int(1, 3);
$num2 = random_int(1, 3);
$num3 = random_int(1, 3);
$num4 = random_int(1, 3);
$num5 = random_int(1, 3);
$num6 = random_int(1, 3);
$num7 = random_int(1, 3);
$num8 = random_int(1, 3);
$num9 = random_int(1, 3);
$num10 = random_int(1, 3);

$vzs1 = random_int(1,4);
$vzs2 = count(2 | $num1, $num2, $num4, $num5, $num6, $num7, $num8, $num9, $num10);
$vzs3 = count(3 | $num1, $num2, $num4, $num5, $num6, $num7, $num8, $num9, $num10);


echo "o valor 1 foi sorteado: ".$vzs1;
echo "  ......................... o valor 2 foi sorteado: ".$vzs2;
echo "  ......................... o valor 3 foi sorteado: ".$vzs3;