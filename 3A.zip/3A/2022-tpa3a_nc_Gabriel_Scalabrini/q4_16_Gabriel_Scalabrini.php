<?php
$aleatorio = 0;
$cont = 0;
$cont2 = 0;
$soma = 0;

while ($cont < 100){
    $aleatorio = rand(0, 10);
    $cont++;
    if ($aleatorio == 10)
    $cont2++; 
    echo(" - ".$aleatorio);
}   
echo("<br> O valor 10 foi sorteado ".$cont2." vezes");
?>