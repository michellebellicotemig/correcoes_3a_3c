<?php
$aleatorio = 0;
$cont = 0;
$soma = 0;

while ($cont < 8){
    $aleatorio = rand(0, 10);
    $cont++;
    if ($aleatorio == 10)
    $soma = $soma + $aleatorio; 
    echo(" - ".$aleatorio);
}   
echo("<br> A soma dos valores iguais a 10 é: ".$soma);
if ($soma >= 10)
echo("<br> A soma dos valores é maior ou igual a 10");
?>