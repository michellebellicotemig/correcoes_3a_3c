<?php
echo('Questão03');

$cont = 0;
$soma;

while($cont < 8){
    echo ($cont);
        $cont++;
    $numeros = rand(0,10);
    
if($cont == 10){
    $soma = $soma + $cont;
}


}
?>
