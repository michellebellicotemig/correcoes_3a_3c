<?php
echo('Questão04');

$cont = 0;
$sorteado;

while($cont < 100){
    echo ($cont);
        $cont++;
    $numeros = rand(0,10);
    
if($cont == 10){
    $sorteado = $sorteado + $cont;
}
}
if($sorteado == 10){
    echo '</br>'
}


?>