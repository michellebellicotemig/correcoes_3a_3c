<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lista de exercicio </title>
</head>
<body>
<?php
ini_set('default_charset','UTF-8');
echo"<h1>Exercicio 1</h1><br>";
$senha=1234;
 if($senha==1234){
echo"Acesso Permitido";
 }
else{
echo"Acesso Negado";
}
echo"<h1>Exercicio 2</h1><br>";
$Produtos="Bacon";
$quantidades=6;
$precos=8; 
if($quantidades < 0 || $quantidades == 0){
echo"preencher corretamente";
}
elseif($quantidades<=5){
    $desconto=$quantidades*$precos*0.02;
    $total=$quantidades*$precos-$desconto;
    echo("total: ".$total);
}
elseif($quantidades>=6 && $quantidades<=10){
    $desconto=$quantidades*$precos*0.03;
    $total=$quantidades*$precos-$desconto;
    echo("total: ".$total);
}
elseif($quantidades>10){
    $desconto=$quantidades*$precos*0.05;
    $total=$quantidades*$precos-$desconto;
    echo("total: ".$total);
}
echo"<h1>Exercicio 3</h1><br>";
$numero=100;
$titular="Silvino";
$saldo=2000;
$tmovimento="Retirada";
$vmovimento=800;

$movimentacao = 800;

if($tmovimento=="Deposito"){
$saldo+=$movimentacao;
echo"Aconteceu uma movimentação do tipo: $tmovimento com um saldo de: $saldo. movimentação: $movimentacao";
}
elseif($tmovimento=="Retirada"){
$saldo-=$movimentacao;
echo"Aconteceu uma movimentação do tipo: $tmovimento com um saldo de: $saldo. movimentação: $movimentacao";
}
echo"<h1>Exercicio 5</h1><br>";
$angulo1=45;
$angulo2=45;
$angulo3=45;
if($angulo1==90 && $angulo2==90 && $angulo3==90){
    echo"Esse triangulo é um triangulo retangulo";
}
elseif($angulo1==91 && $angulo2==45 && $angulo3==45){
    echo"Esse triangulo é obtusangulo";
}
elseif($angulo1==45 && $angulo2==45 && $angulo3==45){
    echo"Esse triangulo é um acutangulo";
}
else{
    echo"erro vazio";
}
echo"<h1>Exercicio 6</h1><br>";
$valor=3000;
$parcelas=12;
$salario=1000;
$vparcelas=333.33;
if($vparcelas<=$salario*0.3){
    echo"Liberar imprestimo";
}
elseif($vparcelas<0){
    echo"erro negativo";
}
else{
    echo"não liberar imprestimo";
}
echo"<h1>Exercicio 7</h1><br>";
$num1="";
$num2="";
$num3="";
$resultado=0;
if($num1>$num2 && $num1>$num3){
    $resultado=$num1;
}
elseif($num2>$num1 && $num2>$num3){
    $resultado=$num2;
}
elseif($num1==""&&$num2==""&&$num3==""){
    $resultado="erro vazio";
}
elseif($num3>$num1 && $num3>$num2){
    $resultado=$num3;
}
elseif($num1==$num2 && $num1==$num3){
$resultado="erro iguais";
}
echo $resultado;
echo"<h1>Exercicio 8</h1><br>";
$diaria = 180;
$dias = 8;
$total = 15;
if($dias > 15){
    $total = $diaria + ($dias * 10);
    echo "O total a pagar é de {$total} com uma taxa de R$ 10 ao dia";
}
elseif
($dias == 15){
    $total = $diaria + ($dias * 12);
    echo"O total a pagar é de {$total} com uma taxa de R$12 ao dia";
}
elseif
($dias < 15 && $dias > 0 ){
    $total = $diaria + ($dias * 15);
    echo"O total a pagar é de {$total} com uma taxa de R$15 ao dia";
}
elseif
($dias < 0){
    $total = $diaria + ($dias * -1);
    echo"Erro. Negativo.";
}
elseif($diaria==""&&$total==""&&$dias==""){
    echo"Erro vazio";
}
echo"<h1>Exercicio 9</h1><br>";
$nome="ze";
$matricula=123456;
$nota1=3;
$nota2=3;
$nota3=3;
$total=$nota1 + $nota2 + $nota3;
if($total >=9 && $total<= 10){
echo"Nome do aluno: {$nome} <br> Número de matricula: {$matricula} <br> Nota final: {$total} <br> Classificação: Conceito A";
}
elseif($total >=7 && $total<= 9){
echo"Nome do aluno: {$nome} <br> Número de matricula: {$matricula} <br> Nota final: {$total} <br> Classificação: Conceito B";
}
elseif($total >=5 && $total<= 7){
echo"Nome do aluno: {$nome} <br> Número de matricula: {$matricula} <br> Nota final: {$total} <br> Classificação: Conceito C";
}
elseif($total >=3 && $total<= 5){
echo"Nome do aluno: {$nome} <br> Número de matricula: {$matricula} <br> Nota final: {$total} <br> Classificação: Conceito D";
}
elseif($total<3){
echo"Nome do aluno: {$nome} <br> Número de matricula: {$matricula} <br> Nota final: {$total} <br> Classificação: Conceito E";
}
echo"<h1>Exercicio 10</h1><br>";
$numdeSim = 2;
if($numdeSim == 2){
    echo "suspeita";
}elseif($numdeSim >= 3 && $numdeSim <= 4){
    echo "cúmplice";
}elseif($numdeSim == 5){
    echo "assassino";
}elseif($numdeSim <= 1 && $numdeSim >= 0){
    echo "Inocente";
}elseif($numdeSim == ""){
    echo "Erro.Vazio";
}else{
    echo "Digite SIM ou NÃO";
}

echo"<h1>Exercicio 14</h1><br>";
$i=0;
$soma=0;
while($i<=3){
if ($i%10==0){
    $soma+=$i;
}
$i++;
}
?>
</body>
