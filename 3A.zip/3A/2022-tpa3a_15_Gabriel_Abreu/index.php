<!DOCTYPE html>
<html>
<body>

<?php

      //Declaração de variáveis
      $texto = "hoje eh carnaval";
      $inteiro = 1; 
      $decimal = 6000.25;
      $booleano = true;

      //Mostrar na tela 
      echo ("Texto: " . $texto); 
      echo("<br/>");
      echo ("Inteiro: " . $inteiro); 
      echo("<br/>");
      echo ("Decimal: " . $decimal); 
      echo("<br/>");
      echo ("Boleano: " . $booleano); 
      echo("<br/>");

      //Operadores básico
      $numero1 = 5;
      $numero2 = 3;
      $numero3 = 8;
      $total = $numero1 + $numero2;

    echo ("Total: " . $total); 
    echo("<br/>");

    $total = $numero3 - $numero1 -1;
    echo ("Total: " . $total); 
    echo("<br/>");

    $total = $numero3/$numero2;
    echo ("Total: " . $total); 
    echo("<br/>");

    $total = $numero2 * 3;
    echo ("Total: " . $total); 
    echo("<br/>");

    //Jogar videogame do DAVI (só precisa de uma das coisas)
    $agendar = "Sim";
    $contraTurno = "Não";
    $notaBoa = "Não";

    if($agendar=="Sim" && $contraTurno=="Sim" && $notaBoa == "Sim"){
        echo ("Vai jogar."); 
        echo("<br/>");
    }else{
        echo ("Não vai jogar."); 
        echo("<br/>");
    }

    if($agendar=="Sim" || $contraTurno=="Sim" || $notaBoa == "Sim"){
        echo ("Vai jogar."); 
        echo("<br/>");
    }else{
        echo ("Não vai jogar."); 
        echo("<br/>");
    }
?>

</body>
</html>