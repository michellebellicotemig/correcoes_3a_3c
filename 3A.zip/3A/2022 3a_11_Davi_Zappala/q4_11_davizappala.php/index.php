<?php
$random = 0;
$i = 0;
$igualUm = 0;
$igualDois = 0;
$igualTres = 0;

while($i < 10){
    $random = rand(1,3);
    echo $random ." - ";

    if($random == 1){
        $igualUm++;
    }

    if($random ==2){
        $igualDois++;

    }

    if($random == 3){
        $igualTres++;
    }

    $i ++;     
} 

echo "<br>O valor 1 foi sorteado " .$igualUm  ." vezes";
echo "<br>O valor 2 foi sorteado " .$igualDois  ." vezes";
echo "<br>O valor 3 foi sorteado " .$igualTres  ." vezes";

?>