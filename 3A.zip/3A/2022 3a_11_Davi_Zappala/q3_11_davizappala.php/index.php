<?php
$random = 0;
$i= 0;
$soma = 0;

while ($i < 10
){
    $random = rand(1,100);
    echo "$random ;  ";
    $soma += $random;
   
$i ++;
}
if ($soma >= 700){
    echo "<br> A soma e maior que 700";
}

else {
     echo "<br> A soma e menor que 700";
}

Echo "<br>A soma dos valores e " .$soma;
?>
