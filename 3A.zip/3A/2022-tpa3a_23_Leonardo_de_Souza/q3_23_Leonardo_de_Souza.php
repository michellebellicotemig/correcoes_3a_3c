<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Questao3</title>
</head>
<body>
<?php

$numero=0;
$Soma = 0;

while($numero<10){
    $Num = rand(0,100);
    $Soma = $Soma + $Num;
    $numero++;
}
if($Soma >= 700){
    echo $Soma . " e maior ou igual a 700";
}elseif($Soma < 700){
    echo $Soma . " e menor que 700";
}
?>
</body>
</html>