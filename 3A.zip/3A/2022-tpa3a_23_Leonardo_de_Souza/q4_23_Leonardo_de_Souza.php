<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Questao4</title>
</head>
<body>
<?php

$cont1 = 0;
$cont2 = 0;
$cont3 = 0;
$numero = 0;


while($numero<10){
    $Num = rand(1,3);
    if($Num == 1){
        $cont1++;
    }elseif($Num == 2){
        $cont2++;
    }elseif($Num == 3){
        $cont3++;
    }
    $numero++;
}
echo "O numero 1 repetiu " . $cont1 . " vezes </br>";
echo "O numero 2 repetiu " . $cont2 . " vezes </br>";
echo "O numero 3 repetiu " . $cont3 . " vezes </br>";
?>
</body>
</html>