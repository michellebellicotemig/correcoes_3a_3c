<?php

echo ('Questao 04');
$cont = 0;
$soma = 0;

//laço de repetição
while ($cont < 100) 
{
//declarando números variaveis
$numeros = rand(0,10);
    
//calculando se o número é igual a 10
if ($numeros % 10 == 0)
{
      $soma += $numeros;
}

//saida
echo ("<br>" .$numeros);
$cont++;
}

//saida
echo ("<br>O numero 10 foi sorteado:" .$soma/10);

?>