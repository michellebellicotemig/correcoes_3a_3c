<?php


//declarar variavel
$cont = 0;
$soma = 0;

echo ('Questao 03');

//while
while ($cont < 8) 
{

//gerando números aleatorios     
$numeros = rand(0,10);


//calculando a soma dos numeros aleatorios
if ($numeros <= 10)
{
    $soma += $numeros;

}

//saida
echo ("<br>" .$numeros);
$cont++;
}



if ($soma > 10 )
{
echo ('<br/> A soma eh maior que 10 !');  
}
else if ($soma = 10)
{
    echo ('<br/> A soma e igual a 10 !');
}
else if ($soma > 10)
{
echo ('<br/> A soma não eh menor que 10 !');
}




?>