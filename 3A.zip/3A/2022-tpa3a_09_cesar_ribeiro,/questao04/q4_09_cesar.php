<?php
echo('Questao04 <br><br>');
$cont = 0;



    while($cont < 10){
        $gerar = rand(1, 3);

        echo($gerar. "<br>");
        $cont++;
    }

    echo("O valor 1 foi sorteado: ".$gerar. "vezes <br>");
    echo("O valor 2 foi sorteado: ".$gerar. "vezes<br>");
    echo("O valor 3 foi sorteado: ".$gerar. "vezes<br>");



?>