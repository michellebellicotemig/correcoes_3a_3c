<?php
 echo("Questao 03 <br><br>");

$cont = 0;
$a1 = 100;
$a2 = -100;
$soma= 0;

while($cont < 10){
    $gerar = rand(0,100);

    if($gerar < $a1){
        $a1 = $gerar;
    }

    if($gerar > $a2){
        $a2 = $gerar;
    }

    if($gerar >= 700){
        $soma += $gerar;

   }  

   if($gerar < 700){
       $soma += $gerar;
    
   }

echo($gerar. "<br>");
$cont++;
}

echo("<br> Soma dos valores maior ou igual a 700?: ".$soma."<br>");
echo("Soma dos valores menor que 700?: ".$soma. "<br><br><br>");

?>