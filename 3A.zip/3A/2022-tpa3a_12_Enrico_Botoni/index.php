<?php
echo rand() . "\n";
echo rand() . "\n";

echo rand(0, 10);
?>