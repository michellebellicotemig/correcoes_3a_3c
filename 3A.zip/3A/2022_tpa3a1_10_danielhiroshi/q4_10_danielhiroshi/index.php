<?php
$aleatorio = 0;
$i = 0;
$resultado = 0;

while($i < 100){
    $aleatorio = rand(0,100);
    echo "$aleatorio - ";

    if($aleatorio == 10){
        $resultado++;
    }


    $i++;
}

if($resultado == 0){
    echo "<br>Nao ha nenhum numero igual a 10 entre os sorteados";
}
else{
    echo "<br>Ha " .$resultado ." numeros igual a 10";
}

?>

