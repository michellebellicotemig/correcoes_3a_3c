<?php
$aleatorio = 0;
$i = 0;
$soma = 0;
while ($i < 8){
    $aleatorio = rand(0,10);
    echo "$aleatorio ; ";
    $soma += $aleatorio;
    $i++;
}
if ($soma >= 10){
    echo "<br>A soma dos valores e maior que 10";
}
else {
    echo "<br>A soma dos valores nao e maior que 10";
}

echo "<br>A soma de todos os valores e:" .$soma;
?>