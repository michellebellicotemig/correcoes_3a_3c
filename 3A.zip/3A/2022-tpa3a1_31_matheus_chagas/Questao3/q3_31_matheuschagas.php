<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
header("Content-Type: text/html ; charset:UTF-8");

$contador = 1;
$soma = 0;
$num1 = 0;
$numeros = $num1;
$igual = 700;


while($contador <=10 ){

$num1 = rand(0,100);
echo $contador . " valor =  " .$num1 ."<br>" ;
$numeros ++;
$soma = $soma + $num1;
$contador ++;


}
echo "<br>"."A soma deles:".$soma;
if($soma < 700){
    echo"<br>"."Soma deles e menor que 700";
}
elseif($soma > 700){
    echo"<br>"."Soma deles e maior que 700";
}
elseif($soma == 700){
    echo"<br>"."Soma deles e igual 700";
}
?>
</body>
</html>




















