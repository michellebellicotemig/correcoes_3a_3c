<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
header("Content-Type: text/html ; charset:UTF-8");

$contador = 1;
$num1 = 0;
$cont1 = 0;
$cont2 = 0;
$cont3 = 0;


while($contador <=10 ){

$num1 = rand(1,3);
echo $contador . " valor =  " .$num1 ."<br>" ;

$contador ++;

if($num1 == 1){
    $cont1++;
}
elseif($num1 == 2){
    $cont2++;
}
elseif($num1 == 3){
    $cont3++;
}
}

echo "<br>"."O numero 1 apareceu:".$cont1 . "vezes";
echo "<br>"."O numero 2 apareceu:".$cont2 . "vezes";
echo "<br>"."O numero 3 apareceu:".$cont3 . "vezes";
?>
</body>
</html>