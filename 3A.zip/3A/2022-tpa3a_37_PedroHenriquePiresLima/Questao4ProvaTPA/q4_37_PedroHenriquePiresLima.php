<?php

$i = 0;
$maior = -100;
$menor = 100;
$soma = 0;
$media;
$quantmenor15 = 0;
while ($i < 6){
    $temperatura = rand(1,3 );

    if($temperatura < $menor){
        $menor = $temperatura;
    }
    if($temperatura > $maior){
        $maior = $temperatura;
    }
    if($temperatura < 15){
        $soma += $temperatura;
        $quantmenor15++;
    }

    echo ("$temperatura , ");
    $i++;

}

echo "<br>O valor 1 foi sorteado: " .$menor;
echo "<br>O valor 2 foi sorteado: " .$maior;
echo "<br>O valor 2 foi sorteado: " .$maior;


?>