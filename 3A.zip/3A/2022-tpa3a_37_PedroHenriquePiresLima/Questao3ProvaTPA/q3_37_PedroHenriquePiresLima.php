
<?php
$i = 0;
$soma = 0;



for ($i = 0; $i< 700;$i++)
{
    if($i % 2 == 0){
        $soma = $soma + $i;
    }

}
if($soma>= 700){
    echo("<br/>A soma e maior ou igual a 700"); 
}else{
    echo("<br/ A soma dos valores é menor que 700");
}
$media = $soma / 700;


echo "<br>A soma dos valores e : " .$media;
echo "<br>A soma dos valores e menor que : " .$soma ;
?>
