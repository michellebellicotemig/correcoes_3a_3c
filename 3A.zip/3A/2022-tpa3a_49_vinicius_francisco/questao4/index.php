<!DOCTYPE html>
<html>
<body>
<?php

$valor1 = 1;
$valor2 = 2;
$valor3 = 3;

$quantidadenumeros = 0;
$numerosaleatorios = 0;

while($numerosaleatorios < 10){ 
    $aleatorio = rand(1,3);

    if($aleatorio == $valor1 ){
        $aleatorio = $quantidadenumeros;
    }
    if($aleatorio == $valor2 ){
        $aleatorio = $quantidadenumeros;
    }
    if($aleatorio == $valor3 ){
        $aleatorio = $quantidadenumeros;
    }

    if( $aleatorio = $quantidadenumeros ){
        $quantidadenumeros++;


    }
$numerosaleatorios++;
}
echo  "O  valor 1 foi sorteado" .$aleatorio ."<br>";
echo  "O  valor 2 foi sorteado" .$aleatorio ."<br>";
echo  "O  valor 3 foi sorteado" .$aleatorio ."<br>";



?>
</body>
</html>
