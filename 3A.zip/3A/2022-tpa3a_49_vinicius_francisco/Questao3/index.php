<!DOCTYPE html>
<html>
<body>
<?php

$cont = 0;
$valormenor = 700;
$soma = 0;
$somadosvalores = 0;

while($cont < 10){
    $soma = rand(0,10);

    if($valormenor < 700){
        $valormenor = $soma;
    }
    echo($soma."<br>");
    $cont++;

}
$somadosvalores =+ $soma;

echo ("Soma dos valores = " .$somadosvalores ."<br>");

echo("Valor menor = " .$valormenor."<br>");



?>
</body>
</html>
