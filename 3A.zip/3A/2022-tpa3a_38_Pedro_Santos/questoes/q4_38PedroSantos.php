<?php
 
 $cont = 0 ; 
 $Soma = $cont ;
 $iguaisa = 0; 
 $resultado = 0;


 while ($cont <= 10) {
$cont = rand(0,100);
 
if ($cont = 10) 
 {
     $resultado = "O valor é igual a 10";
 } 
 else 
  {
    "O valor é diferente que 10";
 }
} 

?>


