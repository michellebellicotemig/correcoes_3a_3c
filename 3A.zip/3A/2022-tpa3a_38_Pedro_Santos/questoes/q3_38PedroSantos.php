<?php
 
 $cont = 0 ; 
 $Soma = $cont ;
 $iguaisa = 0; 
 $resultado = 0;


 while ($cont <= 10) {
$cont = rand(0,10);
 
if ($cont >= 10) 
 {
     $resultado = "O valor é maior ou igual a 10";
 } 
 else 
  {
    "O valor é menor que 10";
 }
} 

?>





