
<!DOCTYPE html>
<html>
<body>
    
<?php 
//Habilitando os acentos e ç
header('Content-Type: text/html; charset=utf-8');

echo "<h1>Questão 3 - Miguel Oliveira Bizzi</h1>";
//MIGUEL OLIVEIRA BIZZI - QUESTAO 3

//variaveis

$num = 0;
$contnum = 0;
$soma = 0;
$cont = 1; 
$somavlrdez = 0;

//calculo
echo "<b>Numeros sorteados: </b>";   
while($contnum < 8){
    
    $num = rand(0,10);
    echo $num .", ";
    $soma += $num;
    if($num == 10){
        $somavlrdez += $num;
    }
    $cont++;
    $contnum++;
    
}
if ($soma >= 10){
    echo "<br><b>A soma dos valores é maior ou igual a 10</b>";
} else{
    echo "<br><b>Se a soma dos valores é menor que 10</b>";
}
echo "<br><b>A soma dos valores iguais a 10: </b>" .$somavlrdez;
echo "<br><b>Soma: </b>" .$soma;


?>


</body>
</html>