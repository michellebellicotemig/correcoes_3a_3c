
<!DOCTYPE html>
<html>
<body>
    
<?php 
//Habilitando os acentos e ç
header('Content-Type: text/html; charset=utf-8');

echo "<h1>Questão 4 - Miguel Oliveira Bizzi</h1>";
//MIGUEL OLIVEIRA BIZZI - QUESTAO 4

//variaveis

$num = 0;
$contnum = 0;
$soma = 0;
$contdez = 0;

//calculo  
echo "<b>Valores de entrada: </b>";
while($contnum < 100){
    $num = rand(0,10);
    echo $num .", ";
    if($num == 10){
        $contdez ++;
    }
    $contnum++;
    
}

echo "<br><br>O valor 10 foi sorteado " .$contdez ." vezes.";


?>


</body>
</html>