<?php


    $soma = 0;

    $aleatorio = 0;

    $count = 0;

    for ($count = 0;  $count <= 8;  $count++) {

        $aleatorio = rand(1,10);


    if($aleatorio == 10)
    {

        $soma += $aleatorio;

    }
}
    echo "A soma dos valores iguais a 10 eh de: ";

if ($soma >= 10)
{

    echo "<br> A soma dos valores eh maior ou igual a 10";

}

else {

    echo "<br> A soma dos valores eh menor ou igual a 10";
}

        ?>