
<!DOCTYPE html>
<html>
<head>
    <title>Tabela e Aviso</title>
</head>



<body>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


<table class="table">
    <thead>
    <tr>

        <th scope="col">-</th>
        <th scope="col">nome</th>
        <th scope="col">sobrenome</th>
        <th scope="col">instagram</th>

    </tr>
    </thead>
    <tbody>
    <tr>
        <th scope="row">1</th>
        <td>Samuel</td>
        <td>Souza</td>
        <td>@_sasa_s22</td>
    </tr>
    <tr>
        <th scope="row">2</th>
        <td>Michelli</td>
        <td>Beli</td>
        <td>@michelli_gata_dmais</td>
    </tr>
    </tbody>
</table>

<div class="alert alert-danger"> Este usuario nao pode ser excluido! </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>

</html>






