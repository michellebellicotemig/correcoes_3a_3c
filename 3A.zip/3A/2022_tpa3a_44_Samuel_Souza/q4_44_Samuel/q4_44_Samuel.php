<?php


$sorteado= 0;
$count= 0;
$aleatorio= 0;

for ($count = 0;  $count <= 100;  $count++) {

    $aleatorio = rand(1,10);

    echo "  $aleatorio , 
   ";

    if ($aleatorio === 10)
    {

        echo " o numero 10 foi sorteado   $sorteado  vezes";

    }
    }
?>