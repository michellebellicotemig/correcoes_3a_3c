<?php 

$cont = 0;
$n = 0;
$s = 0;
$r = 0;

while($cont < 10){

$n = rand(0,100);
echo($n . "<br>");
$cont++;

if( $n <= 100){
    $s = $s + $n;
}

if ($s < 700){
    echo($r <700);
   }
if ($s > 700){
    echo($r >700);
   }
   if ($s = 700){
    echo($r =700);
   }
   
 

}

echo(" soma =  ". $s. "<br>");
echo(" A soma e =" . $r ."<br>");