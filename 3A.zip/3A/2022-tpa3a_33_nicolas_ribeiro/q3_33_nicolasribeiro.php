<!DOCTYPE html>
<html>
<body>

<?php

$i = 0;
$numeros = 0;
$soma=0;
$aleatorios = 0;


if($aleatorios <= 100){
    $numeros = rand(0,100);
    echo("Valores = ".$numeros);
    
    $numeros = rand(0,100);
    echo(" , ".$numeros);
    
    $numeros = rand(0,100);
    echo(" , ".$numeros);
    
    $numeros = rand(0,100);
    echo(" , ".$numeros);

    $numeros = rand(0,100);
    echo(" , ".$numeros);

    $numeros = rand(0,100);
    echo(" , ".$numeros);

    $numeros = rand(0,100);
    echo(" , ".$numeros);

    $numeros = rand(0,100);
    echo(" , ".$numeros);

    $numeros = rand(0,100);
    echo(" , ".$numeros);

    $numeros = rand(0,100);
    echo(" , ".$numeros);
}

for($i = 0; $i <= 700; $i++){
    if($soma){
        $soma = $soma + $aleatorios;
    }
}



















?>

</body>
</html>