<!DOCTYPE html>
<html>
<body>

<?php

$contagem = 0;
$numeros = 0;

if($contagem <= 10){
    $numeros = rand(1,3);
    echo("Valores de entrada ".$numeros);
    
    $numeros = rand(1,3);
    echo(" , ".$numeros);
    
    $numeros = rand(1,3);
    echo(" , ".$numeros);
    
    $numeros = rand(1,3);
    echo(" , ".$numeros);

    $numeros = rand(1,3);
    echo(" , ".$numeros);

    $numeros = rand(1,3);
    echo(" , ".$numeros);

    $numeros = rand(1,3);
    echo(" , ".$numeros);

    $numeros = rand(1,3);
    echo(" , ".$numeros);

    $numeros = rand(1,3);
    echo(" , ".$numeros);

    $numeros = rand(1,3);
    echo(" , ".$numeros);
}














?>

</body>
</html>