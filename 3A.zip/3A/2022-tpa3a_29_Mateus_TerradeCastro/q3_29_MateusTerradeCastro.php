<?php
echo ('Questão 3');

$soma = 0; 

for($i = 0; $i <= 100; $i++){
    $soma = $soma + $i;}
    
    if ($soma >= 700){
    echo ('<br/> A soma dos valores é maior ou igual a 700');
    
    }else {
        echo ('<br/> A soma dos valores é menor que 700');
    
    }

for($i = 0; $i <= 100; $i++){
    $soma = $soma + $i;}

    if ($soma = 328)
        echo ('<br/> A soma dos valores é 328');
        
        if($soma > 328== 700)
                  if ('<br/> A soma dos valores é menor que 700');