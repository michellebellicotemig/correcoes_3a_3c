<?php
echo ('Questão 4');

$soma = 0; 

for($i = 1; $i <= 3; $i++){
    $soma = $soma + $i;}
    
    if ($soma = 4){
    echo ('<br/> o valor 1 foi sorteado 4 vezes');
    
    if ($soma = 8){
        echo ('<br/> o valor 2 foi sorteado 4 vezes');

        if ($soma = 6){
            echo ('<br/> o valor 3 foi sorteado 2 vezes'); 
        }