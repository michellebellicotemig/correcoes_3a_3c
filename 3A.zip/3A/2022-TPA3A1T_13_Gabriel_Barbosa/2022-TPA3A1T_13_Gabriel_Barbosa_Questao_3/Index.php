<?php
$i = 0;
$soma = 0;
$valor = 0;


for ($i = 0; $i<=100;$i++)
{
    if ($soma = $i + $soma);
    

}

while ($valor = $soma <= 700)
{
    echo " sim"; 
}

echo "<br>A soma dos valores e: " .$soma ;
echo "<br>A soma e menor que 700? : " .$valor;
?>