<?php
$num1 =random_int(0,10);
$num2 =random_int(0,10);
$num3 =random_int(0,10);
$num4 =random_int(0,10);
$num5 =random_int(0,10);
$num6 =random_int(0,10);
$num7 =random_int(0,10);
$num8 =random_int(0,10);

if(+ values >=10){
    if (+ values <=10);
}
{
    for(+ values =10 is 20);

    for(+ values >=10);
}



