<!DOCTYPE html>
<html>
<body>

<?php
$resultado = 0;
$i = 1;

while($i <= 100){
    $num = rand(0,10); 
    if($num == 10){
        $resultado++;
    }
    $i++;
}

echo "O valor 10 foi sorteado ".$resultado." vezes";
?>

</body>
</html>