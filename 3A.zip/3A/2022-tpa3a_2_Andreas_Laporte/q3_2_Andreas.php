<!DOCTYPE html>
<html>
<body>

<?php
$i = 1;
$num = rand(0,10);
$soma = 0;

while($i<=8){
    if($num == 10){
        $soma += $num;
    }
    $i ++;
}

$resposta = "A soma dos valores iguais a 10 e ".$soma.".";

if($soma >= 10){
    $resposta2 = "<br> A soma dos valores e maior ou igual a 10.";
}else{
    $resposta2 = "<br> A soma dos valores e menor que 10.";
}

echo $resposta;
echo $resposta2;
?>

</body>
</html>