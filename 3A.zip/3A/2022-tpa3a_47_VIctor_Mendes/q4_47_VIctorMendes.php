<?php 
$cont = 0;
$soma= 0;
$quantidade1 = 0;
$quantidade2 = 2;
$quantidade3 = 3;

while ($cont < 10){
$valor = rand(1,3);

  echo($valor."<br>");
  $cont ++;
  $soma += $valor;
  if ($valor == 1){
    $quantidade1++;
  }
  if ($valor == 2){
    $quantidade2++;
  }if ($valor == 3){
    $quantidade3++;
  }
  


}


echo ('<br/> Apareceu ' .$quantidade1. ' vezes');
echo ('<br/> Apareceu ' .$quantidade2. ' vezes');
echo ('<br/> Apareceu ' .$quantidade3. ' vezes');


?>