<?php

$cont = 0;
$maiorValor = 700;
$soma= 0;

while ($cont < 10){
$valor = rand(0,100);

if($valor<$maiorValor){
  $maiorValor=$valor ;

}
  echo($valor."<br>");
  $cont ++;
  $soma += $valor;
}


if($soma>700){
  echo ('<br/> A soma dos valores e maior que 700');
}else{
  echo ('<br/> A soma dos valores e menor que 700');
}

echo ('<br/> A soma dos valores e '.$soma."<br>");

?>