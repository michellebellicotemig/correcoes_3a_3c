<?php

echo('questao 03');

$soma = 0; 

for($i = 0;$i <= 8;$i++){
    if($i % 2 == 0){
       $soma = $soma +$i; 
     } 
}


if($soma >= 10){
echo('<br/>A soma dos valores iguais  a 10  : ' .$soma);
}else{
echo('<br/>a soma e menor que 10 :' .$soma);
}



