<?php

echo('questao 04');

 
$vezes = 0 ;
$numero = 10 ;

for($i = 0;$i <= 100;$i++){
    if( $i ==10 ){
       $vezes = $numero   ; 
     } 
}


if($vezes = 2 ){
echo('<br/>O valor 10 foi sorteado '.$vezes);
}