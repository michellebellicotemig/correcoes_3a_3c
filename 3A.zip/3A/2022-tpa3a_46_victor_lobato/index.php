<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="style.css" media="screen" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <title>Prova Victor Eanuel Lobato 46</title>
</head>
<body>

<h1>Questao numero 2 </h1>

<div class="alert alert-danger"> O usuario nao pode ser excluido! </div>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nome</th>
      <th scope="col">sobrenome</th>
      <th scope="col">genero músical</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Carne</td>
      <td>de</td>
      <td>Cndario</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Buffos</td>
      <td>Regulares</td>
      <td>sapo</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Tio</td>
      <td>da</td>
      <td>Feira</td>
    </tr>
</table>



   
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>        
</body>
</html>