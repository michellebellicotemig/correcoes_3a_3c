<?php


$soma = 0;
$alea = 0;
$count = 0;


  for ( $count = 0;$count <= 8;$count++){
      $alea = rand(0,10);

     

      if($alea == 10){
        $soma +=$alea;
      }

  }

  echo "A soma dos valores iguais a 10 e ".$soma;

  if($soma >= 10){
      echo"<br>A soma dos valores e maior ou igual a 10";
  }else{
      echo" <br> A soma dos valores e menor ou igual a 10";
  }


  

?>