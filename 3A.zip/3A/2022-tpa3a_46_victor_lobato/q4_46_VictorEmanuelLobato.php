<?php


$soma = 0;
$alea = 0;
$count = 0;


  for ( $count = 0;$count <= 100;$count++){
      $alea = rand(0,10);

     

      if($alea == 10){
        $soma ++;
      }

  }

  echo "O valor 10 aparereceu ".$soma." Vezes";

 

  

?>