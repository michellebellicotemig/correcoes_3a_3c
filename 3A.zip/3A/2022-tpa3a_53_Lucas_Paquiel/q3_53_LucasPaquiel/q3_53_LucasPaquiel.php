<?php
$i = 1;
while ($i >= 1 && $i <= 20) {
    $valor = rand(0, 2);
    echo ($i .  ") " . $valor . "<br>");
    if($valor == 0)
    



    $i++;

}




?>
