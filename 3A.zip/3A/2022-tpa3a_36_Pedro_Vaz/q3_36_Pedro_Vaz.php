<?php

echo ("Questao 03</br>");


$cont = 0;
$soma =0;

while($cont<8){

    $numero = rand(0,10);
    echo ($numero."</br>");
    $cont++;

}
?>