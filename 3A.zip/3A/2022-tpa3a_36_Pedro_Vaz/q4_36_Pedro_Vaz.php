<?php

echo ("Questao 03</br>");


$cont = 0;

while($cont<100){

    $numero = rand(0,10);
    echo ($numero);
    $cont++;

    if($cont=10);
    echo("O valor 10 foi sorteado" +$numero + "vezes!");
}
?>