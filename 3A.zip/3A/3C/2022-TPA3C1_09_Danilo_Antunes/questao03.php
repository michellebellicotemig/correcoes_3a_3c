<?php
$qtdMenor = 0;
$maiorNota = -100;
$cont = 0;
for($i = 0; $i < 5; $i++){
    $i = rand(0, 30);
    if($i<15){
        $qtdMenor++;
    }
    if($i > $maiorNota){
        $maiorNota = $i;
    }
    $cont++;
}

echo("Quantidade de notas abaixo de 15: ".$qtdMenor);
echo("A maior nota". $maiorNota);