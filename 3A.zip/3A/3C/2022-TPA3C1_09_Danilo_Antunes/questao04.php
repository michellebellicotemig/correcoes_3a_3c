<?php
$cont = 0;
$qtd6 = 0;
for($i = 0; $i < 100;$i++){
$i = rand(0,100);
echo("".$i);
if($i == 6){
$qtd6++;
}else{
    $cont++;
}
}


echo("<br>O valor 6 foi adivinhado ".$qtd6." vezes");
