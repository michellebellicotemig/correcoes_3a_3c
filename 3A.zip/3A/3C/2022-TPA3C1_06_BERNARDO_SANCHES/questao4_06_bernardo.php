<?php
echo "<h1>Jogo de adivinhar</h1><br>";
echo("Valor da ser adivinhado e 6<br>");
$valor=0;
$cont=0;
$valorAdinvinhado=6;

for ($cont=0;$cont<=100;$cont++){
    $valor=random_int(1,100);
    echo("Valor sorteado $valor<br>");
    if($valor==6){
        $valorAdinvinhado++;
    }
}echo ("<h1>O valor 6 foi sorteado $valorAdinvinhado vezes </h1>");

?>