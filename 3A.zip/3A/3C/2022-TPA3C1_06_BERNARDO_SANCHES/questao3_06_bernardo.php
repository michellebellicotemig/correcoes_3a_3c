<?php
echo "<h1>Jogo do dado<h1/><br>";
$soma=0;
$msg=" ";
$num=0;
$cont=0;

for ($cont=0;$cont<3;$cont++){
$num=random_int(1,6);
$soma=$soma+$num;

}
echo("Soma dos dados = $soma<br>");
if($soma<5){
    echo("Decida o destino ao jogador da direita");
}
else if ($soma==5){
    echo("Compre uma nova carta");
}
else{
    echo("Escolha um jogador que vai perder a rodada");
}

?>