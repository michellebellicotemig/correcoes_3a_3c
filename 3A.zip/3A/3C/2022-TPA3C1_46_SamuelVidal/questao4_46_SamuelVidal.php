<?php 

$contar = 0 ;

for($i = 0; $i <= 99; $i++){

$valor = rand(1,100);

echo"<br> $valor";

if($valor == 6){
    $contar++;
}
}


echo"<br>------------------------------------- <br>";
echo"$contar";




?>