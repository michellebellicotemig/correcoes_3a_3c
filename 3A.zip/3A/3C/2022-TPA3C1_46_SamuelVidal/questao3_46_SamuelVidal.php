<?php

$valor1 = 1;
$valor2 = 2;
$valor3 = 3;
$soma = $valor1 + $valor2 + $valor3;

echo"Os dados foram jogados e a sorte lancada. A soma dos valores sorteados e  $soma" ;
echo"<br>"; 

if($soma < 5){
    echo"Decida o destino do jogador a direita.";
    echo"<br>";
}
else if($soma == 5){
    echo"Compre uma nova carta";
    echo"<br>";
}
else if($soma > 5){
    echo"Escolha o jogador que perdera uma rodada.";
    echo"<br>";
}


?>