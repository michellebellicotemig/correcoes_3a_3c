<?php

    //aceitar acento;
    header("Content-type:text/html; charset=utf8");


    $Numero = 0;
    $Qntd = 0;

    for($i = 0; $i<100; $i ++){
        $Numero  = rand(1,6);

        if($Numero == 6){
            $Qntd++;
        }
    }

    echo "Numero: ".$Numero. "<br>";
    echo "Quantidade: ".$Qntd."<br>";
    echo "O valor foi adivinhado: ".$Qntd."<br>";

?>