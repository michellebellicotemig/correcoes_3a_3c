<?php

    //aceitar acento;
    header("Content-type:text/html; charset=utf8");

    //Sorteie 5 numeros;
    //quantidade menor que 15.
    //maior nota.
    

   
    $maiorNota = 0;
    $qntdMenor = 0;

    for($i = 0;  $i <5; $i++){

        $Nota = rand(0,20);

        if($Nota < 15){
            $qntdMenor++;
        }

        if($Nota > $maiorNota){
            $maiorNota = $Nota;
        }
    }
    
    echo "Quantidade de menores = " .$qntdMenor . "<br>";
    echo "Maior numero = " .$maiorNota. "<br>";

?>