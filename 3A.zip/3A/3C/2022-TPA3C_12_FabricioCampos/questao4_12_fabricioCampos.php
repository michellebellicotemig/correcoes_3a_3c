<?php
$valor = 4;
$loop = rand(1,100);
$i = 0;

for($i = 0;$i <= 100;$i++)
{
    echo $loop;
    if($loop <= $valor)
    {
        echo("O numero 4 apareceu");

    }

}


?>