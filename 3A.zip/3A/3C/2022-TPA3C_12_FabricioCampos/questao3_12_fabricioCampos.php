<?php
$soma = 0;
$i = 0;


for($i = 0;$i < 7;$i++)
{
    $lancamentoi = rand(1,6);
    if($soma += $lancamentoi < 5)
    {
        echo("O jogador à direita vai voltar duas casas");
    }
}

for($i = 0;$i < 7;$i++)
{
    if($soma += $lancamentoi == 5)
    {
        echo("O jogador devera comprar uma nova carta");
    }
}

for($i = 0;$i < 7;$i++)
{
    if($soma += $lancamentoi > 5)
    {
        echo("O jogador 2, perdeu uma rodada .");
    }
}
?>