<?php

$cont = 0;
$Soma = 0;

while($cont <3){
$dado = rand(1,6);
$soma= $dado + $dado + $dado;
echo("Os dados foram jogados e a sorte lancada. A soma dos valores sorteados e ".$soma."<br>");

if($soma< 5){
echo("Decida o destino do jogador a direita."."<br>");
}

else if ($soma = 5){
echo("Compre uma nova carta."."<br");
}
else if ($soma > 5){
echo("Escolha o jogador que perdera uma rodada."."<br");
}
$cont++;
}
?>