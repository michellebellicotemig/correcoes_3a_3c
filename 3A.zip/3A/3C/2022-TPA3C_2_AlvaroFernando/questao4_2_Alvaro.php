<?php

$cont = 0;
$soma = 0;

while($cont <100){
$aleatorio = rand(0,100);

if($aleatorio == 6){
$soma++;
}
$cont++;
}

echo("O valor 6 foi adivinhado ".$soma."vezes"."<br>");

?>