<?php

$valor6 = 0;
$i = 0;

for($i = 0; $i <= 99; $i++){
    $aleatorio = rand (1,100);


if ($aleatorio == 6 ){
    $valor6++;
}
}
echo "o valor 6 foi adivinhado: {$valor6} vezes ";