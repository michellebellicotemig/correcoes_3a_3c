<!-- “Simule 3 lançamentos de um dado tradicional (1-6) apresentando o resultado:
➔ Se a soma dos valores for menor que 5: Decida o destino do jogador à direita.
➔ Se a soma dos valores for igual a 5: Compre uma nova carta.
➔ Se a soma dos valores for maior que 5: Escolha o jogador que perderá uma rodada.”
Saídas esperadas supondo que foram sorteados: 1,2 e 5:
● Os dados foram jogados e a sorte lançada. A soma dos valores sorteados é 8.
● Você deverá escolher qual jogador perderá uma rodada.
● Critérios de correção observando o código-fonte:
○ 1,0 pt - Utilizou corretamente o laço de repetição?
○ 2,0 pt - Criou uma estrutura que apresente a soma dos 3 valores?
○ 1,0 pt - Criou uma estrutura capaz de identificar se a soma é maior, menor ou igual a 5?
-->

<?php

$soma = 0;
$i = 0;

for($i = 0; $i < 3; $i++) 
{
    $aleatorio = rand (1,6);
    echo "dado{$i} valor {$aleatorio} ";
    echo "<br>";
    $soma = $soma + $aleatorio;
}
echo "o valor da soma e {$soma}";
echo "<br>";
if ($soma < 5){
    echo " Decida o destino do jogador a direita.";
    echo "<br>";
} 
if ($soma == 5)
{
    echo "Compre uma nova carta";
    echo "<br>";
}
if ($soma > 5){
    echo "escolha o jogador que perdera uma rodada.";
    echo "<br>";
}



?>