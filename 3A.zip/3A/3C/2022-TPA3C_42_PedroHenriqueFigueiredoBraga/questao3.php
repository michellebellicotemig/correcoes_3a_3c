<?php
$dado1=rand(1,6);
$dado2=rand(1,6);
$dado3=rand(1,6);
$soma = $dado1 + $dado2 + $dado3;

echo ("Resultado dado 1   " . $dado1);
echo ("Resultado dado 2  " . $dado2);
echo ("Resultado dado 3  " . $dado3);
echo ("Resultado dado soma dos dados e" . $soma);

if ($soma < 5){


    echo"Decida o destino do jogador à direita.";
}
if ($soma == 5){


    echo"Compre uma nova carta.";
}

if ($soma > 5){



    echo "Escolha o jogador que perderá uma rodada.";
}