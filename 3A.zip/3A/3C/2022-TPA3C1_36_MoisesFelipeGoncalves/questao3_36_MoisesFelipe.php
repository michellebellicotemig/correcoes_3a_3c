<?php
$soma = 0;

for($i = 0; $i < 4; $i++)
{
    $i = rand(1,6);
    $soma += $i;

    if($soma < 5)
    {
        echo ("Decida o destino do jogador a direita.<br/>");
    }
    else if($soma == 5)
    {
        echo ("Compre uma nova carta.");
    }
    else{
        echo ("Escolha o jogador que perdera uma rodada.<br/>");
    }

}
echo ("Numeros sorteados:" . $i);
echo ("Soma dos valores sorteados:" . $soma);
//QUESTÃO 4
$valoradvinhado = 6;
$contador = 0;
for($i = 0; $i < 100; $i++)
{
    $i = rand(1,100);

    if($i == 6)
    {
        $contador++;
    }
}

echo("<br/> Valor de entrada: " . $i);
echo("O valor 6 foi adivinhado:" . $contador);

?>