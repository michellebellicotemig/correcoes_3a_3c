<?php
$i = 0;
$cont = 0;
$valorseradivinhado = 0;

while($cont<100){
    $i = rand(0,100);
    if($i == 6){
        $cont++;
    }
    $cont++;
    echo $i;
    echo("</br>");
    if($i == 6){
        echo("O valor 6 foi adivinhado 3 vezes");
    }
}