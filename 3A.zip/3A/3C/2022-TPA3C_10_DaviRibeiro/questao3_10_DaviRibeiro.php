<?php

//Se a soma dos valores for menor que 5: Decida o destino do jogador à direita.
//Se a soma dos valores for igual a 5: Compre uma nova carta.
//Se a soma dos valores for maior que 5: Escolha o jogador que perderá uma rodada.

$i = 0;
$cont = 0;
$soma = 0;


while($cont < 3){
    $i = rand(1,6);
    $soma += $i;
    $cont++;
}

echo("a soma dos valores sorteados e: " . $soma);


if($soma < 5){
echo(" Decida o destino do jogador a direita.");
}

if($soma == 5){
    echo(" Compre uma nova carta.");
}

if($soma > 5){
        echo(" Escolha o jogador que perdera uma rodada.");
}
