<?php
$cont = 0;
$valor1 = rand(0,30);
$valor2 = rand(0,30);
$valor3 = rand(0,30);
$valor4 = rand(0,30);
$valor5 = rand(0,30);
 

echo "$valor1 </br>";
echo "$valor2 </br>";
echo "$valor3 </br>";
echo "$valor4 </br>";
echo "$valor5 </br>";


if ($valor1 < 15){
    $cont ++;
}
if ($valor2 < 15){
    $cont ++;
}
if ($valor3 < 15){
    $cont ++;
}
if ($valor4 < 15){
    $cont ++;
}
if ($valor5 < 15){
    $cont ++;
}
echo ("Notas Menores que 15 = $cont");
echo "</br>";

if ( $valor1 > $valor2 && $valor3 && $valor4 && $valor5){
    echo ("A maior nota foi a nota na pocisao 1 ");
}
else if ( $valor2 > $valor1 && $valor3 && $valor4 && $valor5){
    echo ("A maiir nota foi a nota na pocisao2 ");
}
else if ( $valor3 > $valor2 && $valor1 && $valor4 && $valor5){
    echo ("A maior nota foi a nota na pocisao 3 ");
}
else if ( $valor4 > $valor2 && $valor3 && $valor1 && $valor5){
    echo ("A maior nota foi a nota na pocisao 4 ");
}
else if ( $valor5 > $valor2 && $valor3 && $valor4 && $valor1){
    echo ("A maior nota foi a nota na pocisao  5 ");
}
?>