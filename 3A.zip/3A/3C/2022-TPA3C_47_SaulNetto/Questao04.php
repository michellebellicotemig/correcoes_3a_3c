<?php
$cont = 0;

for ($i = 0; $i <= 99; $i++ ){
    $valor = rand (1,100);
    echo "<br> $valor";

    if ($valor == 6){
        $cont ++;
    }
}

echo "</br>";
echo "</br>";
echo "A quantidade de valores foi igual a $cont"


?>