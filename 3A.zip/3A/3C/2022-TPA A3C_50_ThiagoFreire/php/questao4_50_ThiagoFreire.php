//questao3
<?php
$variavel = 0;
for($i = 0; $i <=99; $i++){
    $inteiro = rand(1,100);
    if($inteiro ==6){
        $variavel++;
    }
}
echo "O valor final 6 foi adivinhado {$variavel} vezes";

?>