<?php
$conta = 0;
$contador = 0;
$somatoria = 0;


for($conta = 0; $conta<6;$conta++){
$aleatorio=rand(1,100);
$somatoria+= $conta;
if($aleatorio==6){
    $contador++;
}

}
echo"O valor 6 foi adivinhado ".$contador." vezes";



?>