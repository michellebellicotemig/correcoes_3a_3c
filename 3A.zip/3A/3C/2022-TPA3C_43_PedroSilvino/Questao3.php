<?php
$notas;
$menornota;
$maiornota = -1000;
$contador = 0;
$cont = 0;


for($i=0; $i <= 4; $i++){
    $notas = rand(10,30);
    
    echo($notas."<br>");
    if($notas<15){
        $contador++;
    }
    if($notas > $maiornota){
        $maiornota = $notas;
    }
    
    
}
echo"O numero de notas menor que 15 foi:".$contador."<br>";


echo"A maior nota:".$maiornota;
 
?>