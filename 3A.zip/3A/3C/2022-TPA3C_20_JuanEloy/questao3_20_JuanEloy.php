<!DOCTYPE html>
<html>
<body>
    <?php header("Content-type:text/html; charset=utf8");
      $dado1 = rand(1,6);
      $dado2 = rand(1,6);
      $dado3 = rand(1,6);
      $soma = 0;
      echo "Numero 1: " . $dado1;

      echo("<br/>");

      echo "Numero 2: " . $dado2;

      echo("<br/>");

      echo "Numero 3: " . $dado3;

      echo("<br/>");

    if($soma = $dado1 + $dado2 + $dado3){
        echo"Soma: $soma";
    }

    echo("<br/>");
    
    if($soma > 5){
        echo("Jogador á direita.");
    }  
    else if($soma == 5){
        echo("Compre uma nova carta.");
    }
    else if($soma < 5){
        echo("Jogador da direita perdeu!");
    }

    ?>
</body>
</html>