<!DOCTYPE html>
<html>
<body>
    <?php header("Content-type:text/html; charset=utf8");
      $rando1 = rand(0,100);
      $rando2 = rand(0,100);
      $rando3 = rand(0,100);
      $rando4 = rand(0,100);
      $rando5 = rand(0,100);
      $rando6 = rand(0,100);
      $rando7 = rand(0,100);
      $rando8 = rand(0,100);
      $rando9 = rand(0,100);
      $rando10 = rand(0,100);
      $rando11 = rand(0,100);
      $rando12 = rand(0,100);
      $rando13 = rand(0,100);
      $cont = 0;

      echo "Numero: " . $rando1;
      echo("<br/>");

      echo "Numero: " . $rando2;
      echo("<br/>");

      echo "Numero: " . $rando3;
      echo("<br/>");

      echo "Numero: " . $rando4;
      echo("<br/>");

      echo "Numero: " . $rando5;
      echo("<br/>");

      echo "Numero: " . $rando6;
      echo("<br/>");

      echo "Numero: " . $rando7;
      echo("<br/>");

      echo "Numero: " . $rando8;
      echo("<br/>");

      echo "Numero: " . $rando9;
      echo("<br/>");

      echo "Numero: " . $rando10;
      echo("<br/>");

      echo "Numero: " . $rando11;
      echo("<br/>");

      echo "Numero: " . $rando12;
      echo("<br/>");

      echo "Numero: " . $rando13;
      echo("<br/>");


    if($rando1 == 6){
        $cont ++;
    }
    else if($rando2 == 6){
        $cont ++;
    }
    else if($rando3 == 6){
        $cont ++;
    }
    else if($rando4 == 6){
        $cont ++;
    }
    else if($rando5 == 6){
        $cont ++;
    }
    else if($rando6 == 6){
        $cont ++;
    }
    else if($rando7 == 6){
        $cont ++;
    }
    else if($rando8 == 6){
        $cont ++;
    }
    else if($rando9 == 6){
        $cont ++;
    }
    else if($rando10 == 6){
        $cont ++;
    } else if($rando11 == 6){
        $cont ++;
    }
    else if($rando12 == 6){
        $cont ++;
    }
    else if($rando13 == 6){
        $cont ++;
    }

    echo "A quantidade de numero 6 é: $cont";
    ?>
</body>
</html>