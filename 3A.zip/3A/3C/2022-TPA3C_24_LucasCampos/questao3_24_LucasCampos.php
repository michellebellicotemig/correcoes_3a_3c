<?php
$i = 0;
$cont = 0;
$soma = 0;

while($cont<3)
{
$i = rand(1, 6);
$soma += $i;
$cont++;
}
echo "A soma dos valores sorteados e  " . $soma;
echo "<br><br>";

if($soma<5)
{
    echo "Decida o destino do jogador a direita";
}elseif($soma==5)
{
    echo "Compre uma nova carta";
}else{
    echo "Escolha o jogador que perdera uma rodada.";
}



?>
