<?php
$i = 0;
$cont = 0;
$valoradivinhado = 6;
$cont6 = 0;
echo "Valores de entrada: ";
while($cont<100)
{
    $i = rand(0, 100);
    if($i == 6)
    {
        $cont6++;
    }
    $cont++;
    echo  $i;
}
echo "<br><br>";
echo "Valor a ser adivinhado: " . $valoradivinhado;
echo "<br><br>";
echo "O valor ".$valoradivinhado." foi adivinhado ".$cont6." vezes";


?>