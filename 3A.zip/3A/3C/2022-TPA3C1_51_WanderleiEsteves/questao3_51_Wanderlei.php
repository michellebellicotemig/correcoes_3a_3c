<?php 
header('Content-type:text/html;charset=utf8');

$maior = PHP_INT_MIN;
$menores15 = 0;

$vetor = array();

for($i = 0; $i < 5; $i++)
{
    $vetor[$i] = rand(0,25);

        if($vetor[$i] < 15) 
        {
            $menores15++;
        }

        if($vetor[$i] > $maior)
        {
            $maior = $vetor[$i];
        }
}

// Fiz essa estrutura pq no seu exemplo tava escrito(Um) e não (1) :D

switch($menores15) 
{
    case 0:
        echo "Nenhuma nota ficou abaixo de 15.<br/><br/>";
    break;

    case 1:
        echo "Uma nota ficou abaixo de 15.<br/><br/>";
    break;

    case 2:
        echo "Duas notas ficaram abaixo de 15.<br/><br/>";
    break;

    case 3:
        echo "Três notas ficaram abaixo de 15.<br/><br/>";
    break;

    case 4:
        echo "Quatro notas ficaram abaixo de 15.<br/><br/>";
    break;

    case 5:
        echo "Cinco notas ficaram abaixo de 15.<br/><br/>";
    break;
}

echo "A maior nota foi " . $maior;

?>