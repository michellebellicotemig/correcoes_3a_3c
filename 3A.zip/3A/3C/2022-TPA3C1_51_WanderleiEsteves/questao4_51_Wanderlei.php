<?php 
header('Content-type:text/html;charset=utf8');

$igual6 = 0;

$vetor = array();

for($i = 0; $i < 100; $i++)
{
    $vetor[$i] = rand(1,6);

        if($vetor[$i] == 6) 
        {
            $igual6++;
        }
}

if($igual6 == 1)
{
    echo "O valor 6 foi adivinhado " . $igual6 . " vez";
}else 
{
    echo "O valor 6 foi adivinhado " . $igual6 . " vezes";
}

?>