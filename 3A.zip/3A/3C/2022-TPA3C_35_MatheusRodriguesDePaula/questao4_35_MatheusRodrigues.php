<?php
    $cont = 0;

    for ($i=0; $i <= 100; $i++) { 
        $valores = rand (1,100);
    
        if($valores == 6){
            $cont++;
        }
    }   
    echo ("Numero de vezes que o valor adivinhado saiu : ".$cont);





    
?>

