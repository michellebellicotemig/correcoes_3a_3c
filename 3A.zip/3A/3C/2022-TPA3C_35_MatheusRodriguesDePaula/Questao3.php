<?php

 $nota15 = 0;

for ($i=0; $i < 5; $i++) { 
    $nota = rand(0,30);
 if($nota < 15){
     $nota15++;
    }
}
    echo("O numero de notas abaixo de 15 sao : " .$nota15);
?>