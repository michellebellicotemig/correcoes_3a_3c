<?php

$valores = rand(1,100);
$repeticoes = 6;

if ($valores = $repeticoes){
    echo ("O valor foi adivinhado " . $repeticoes . " vezes.");
} else {
    echo "O valor nao apareceu nenhuma vez";
}

?>