<?php

// não sei nada sou uma decepção

$valor1 = 25;
$valor2 = 30;
$valor3 = 22;
$valor4 = 13;
$valor5 = 15;

if ($valor1 < 15 || $valor2 < 15 || $valor3 < 15 || $valor4 < 15 || $valor5 < 15){
    echo "A quantidade de notas que e menor que 15";
}

?>