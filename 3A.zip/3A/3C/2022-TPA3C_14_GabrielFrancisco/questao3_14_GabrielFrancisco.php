<?php

$cont = 1;
$dado = 0;
$soma = 0;

while ($cont < 4){

    $dado = rand(1,6);
    echo "Lancamento " . $cont . " = " . $dado . "<br><br>";
    $soma += $dado;
    $cont++;

}

echo "Os dados foram jogados e a sorte lancada. A soma dos valores sorteados e " . $soma . ".<br>";

if($soma < 5){
    echo "Decida o destino do jogador a direita.";


}

if($soma == 5){
    echo "Compre uma nova carta.";


}

if($soma > 5){
    echo "Escolha o jogador que perdera uma rodada.";


}
