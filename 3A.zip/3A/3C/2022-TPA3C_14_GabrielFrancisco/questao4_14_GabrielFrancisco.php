<?php

$cont = 0;
$aleatorio = 0;
$valoradivinhado = 7;
$identificador = 0;

echo "Valor a ser adivinhado =  " . $valoradivinhado . ".<br><br> ";


while ($cont <= 100){

    $aleatorio = rand(0,100);
    echo "Numero " . $cont . " = " . $aleatorio . "<br>";

    if($aleatorio == $valoradivinhado){
        $identificador++;

    }
    $cont++;
}

echo "<br> O valor " . $valoradivinhado . " foi adivinhado " . $identificador .  " vezes.";
