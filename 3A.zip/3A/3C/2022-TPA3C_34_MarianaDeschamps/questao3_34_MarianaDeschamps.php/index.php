<?php
$soma = 0;


// USANDO LAÇO DE REPETIÇÃO;
for($i =0; $i<=18; $i++){
    $soma + $i;
}

if($soma <5){
echo "Decida o destino do jogador a direita";
}
elseif($soma == 5){
echo " Compre uma nova carta.";
}
else{
echo "Escolha o jogador que perdera uma rodada.";
}

?>