<?php
$cont = 0;
$aleatorio = rand(1,100);

for($i =0; $i <= 100; $i++){
    $aleatorio= rand(1,100);
    if($aleatorio == 6)
      { 
        $cont++;
        echo("o numero foi: ".($cont));
      }
    }      
?>
