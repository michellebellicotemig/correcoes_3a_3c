<?php
echo("Questao 4</br>");

//variaveis


$valor= 6;
$cont=0;

//contas
for($i=0; $i<=99; $i++){
    $aleatorio= rand(0,100);
    echo $aleatorio ."<br/>";
    if($aleatorio==6){
        $cont++; 
    }
}
echo "Quantos apareceram? " . $cont ."<br/>";

