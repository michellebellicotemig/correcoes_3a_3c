<?php
echo("Questao 3</br>");

//variaveis


$soma= 0;


//contas
for($i=0; $i<=2; $i++){
    $aleatorio= rand(1,6);
    echo $aleatorio ."<br/>";
    $soma = $soma + $aleatorio;
    echo "soma" . $soma ."<br/>"; 
}
if($soma<5){
    echo("</br>Decida o destino do jogador a direita.");
}elseif($soma==5){
    echo("</br>Compre uma nova carta.");
}else{
    echo("</br>Escolha o jogador que perdera uma rodada.");
}
