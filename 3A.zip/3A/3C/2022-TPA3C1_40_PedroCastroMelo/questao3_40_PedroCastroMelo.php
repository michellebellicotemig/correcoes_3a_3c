<?php
$dado1 = rand(1,6);
$dado2= rand(1,6);
$dado3= rand(1,6);
$soma = $dado1 + $dado2 + $dado3;

echo("Resultado dado 1::". $dado1);
echo("<br>Resultado dado 2::". $dado2);
echo("<br>Resultado dado 3::". $dado3);
echo("<br>Resultado da soma dos 3 dados::". $soma);
if($soma < 5)
{
    echo("<br>Decida o destino do jogador a direita.");
}
if($soma == 5)
{
    echo("<br>Compre uma nova carta.    ");
}

if($soma > 5)
{
    echo("<br> Escolha o jogador que perdera uma rodada.");
}



?>