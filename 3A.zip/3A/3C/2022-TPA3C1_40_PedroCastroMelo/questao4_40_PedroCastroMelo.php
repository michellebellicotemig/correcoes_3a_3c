<?php
$numeror = 0;
$numero = 0;

for($i = 0;$i < 100;$i++)
{
    $numeror = rand(0, 100);
    if($numeror == 6)
    {
        $numero += 1;
        echo("Foram encontrados " . $numero . " valores iguais a 6.");
    }

}
echo("I LOVE YOU FESSORA :] <3")


?>