<?php

// Sortear 5 valores referente a nota de alunos
// a qntd de notas que é menor que 15
// a maior nota
// saidas
// Uma nota ficou abaixo de 15.
// A maior nota foi 30.5.

$maiornota = 0;
$notasmenor15 = 0;


for($i = 0; $i < 5; $i++){

    $nota = rand(0, 30);
    
    if($nota < 15){
        $notasmenor15++;
    }

    if($nota > $maiornota){
        $maiornota = $nota;
    }
    
}
echo($notasmenor15." nota ficou abaixo de 15.</br>");
echo("A maior nota foi ".$maiornota.".</br>");

?>