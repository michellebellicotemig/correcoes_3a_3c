<?php

$valor = 0;
$qntde6 = 0;

for($i = 0; $i < 100; $i++){
    
    $valor = rand(1, 6);
    
    if($valor == 6){
        $qntde6++;
    }
    
}
echo("O valor 6 foi adivinhado ".$qntde6." vezes");

?>