<?php
$numero = 0;
$numero = 0;

for ($i = 0; $i <= 30.5; $i++)
    $numero = rand(1,30.5);
    if($numero ==30.5)
    {
        $numero+= 1;
        echo("a maior nota e ");
    }
    if($numero<15)
    {
        $numero+=1;
        echo("os valoes menores sao");
    }


?>