<?php

$cont = 0;
$soma = 0;
while($cont >=1 && $cont <= 6){
    if($cont == 3 ){
        $soma = $cont + $soma;

        if($soma < 5){

            Echo ("Decida o destino do jogador a direita");

        }
        if($soma == 5){

            Echo ("Compre uma nova carta");
        }
        if($soma > 5){

            Echo ("Escolha o jogador que perdera uma rodada");
        }

    }
    $cont++;

}
echo "<br>";
echo "A soma dos valores sorteados é  " .$soma;




