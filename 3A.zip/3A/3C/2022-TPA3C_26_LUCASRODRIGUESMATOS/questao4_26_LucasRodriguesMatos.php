<?php
$valor_pra_adivinhar = 6;
$cont = 0;

while($cont >=1 && $cont <= 100){
    if($valor_pra_adivinhar == 0) {

        Echo("O valor 6 nao foi sorteado");


    elseif
        ("O valor 6 foi sorteado");
    }







