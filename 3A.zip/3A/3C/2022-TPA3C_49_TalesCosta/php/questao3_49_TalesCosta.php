<?php
$notas = 0;
$soma = 0;
$maior = 0;
for ($i = 0; $i <=4; $i++)
{
$notas = rand(1,100);
    if($notas < 15)
    { 
        $soma++;
    }
    if($notas > $maior)
    { 
        $maior++;
    } 
}
echo "quantidade de notas menor que 15 é igual a{$soma}";
echo "A maior nota é {$maior}";
?>s