<?php
$inteiro = 0;
for ($i = 0; $i <=99; $i++)
{
    $inteiro = rand(1,100);
    if($inteiro == 6)
    {
        $inteiro++;
    }
 echo"6 foi adivinhado {$inteiro} vezes";
}
?>