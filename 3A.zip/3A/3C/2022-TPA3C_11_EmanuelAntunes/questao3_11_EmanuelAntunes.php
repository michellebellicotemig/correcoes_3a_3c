<?php

$notas = rand(0, 30.5);
$n15 = 0; $quantidade15 = 0; $maior = 0;

        for($i = 0; $i <= 4; $i++)
        {
            $notas = rand(0, 30.5);
            echo "As notas geradas sao: ".$notas."<br><br>";

                if ($notas < 15)
                {
                    $n15 = $notas;
                    $quantidade15++;
                }

                if ($notas > $maior)
                {
                    $maior = $notas;
                }
            }
            echo $quantidade15." notas ficaram abaixo de 15 <br><br>";
            echo "A maior nota e ".$maior."<br><br>";

?>