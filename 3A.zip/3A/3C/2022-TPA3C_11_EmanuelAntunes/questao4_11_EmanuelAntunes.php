<?php

$dados = array(1,2,3,4,5,6);
$valor6 = 0;

// desisti de fazer um valor aleatorio.
//$x = rand(1, 6);

for($cont = 0; $cont <= 99; $cont++){
    for($i = 0; $i <= 5; $i++){

        if($dados[$i] == 6){
            $valor6++;
        }
    }
}

echo "O valor 6 foi adivinhado ".$valor6." vezes <br><br>";

?>