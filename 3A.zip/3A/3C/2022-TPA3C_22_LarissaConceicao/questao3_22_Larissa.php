<?php 

for($i =1; $i<=6; $i++){
    $valores = rand(1,6);
    
    "<br>";
    $soma = $valores + $valores;
    echo $valores . "<br>";
    if($soma < 5){

        echo " Decida o destino do jogador a direita "; 
        
    }else if ($soma > 5) {
        echo "Escolha o jogador que perdera uma rodada "; 
        
    }
    else if($soma = 5){
        echo "Compre uma nova carta "; 
    }
    echo $valores . "<br>";

    
}


?>
