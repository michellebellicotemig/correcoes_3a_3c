<?php 
for($i =0; $i<=100; $i++){
    $valores = rand(0,100);
    echo $valores . "<br>";
    
    
} 


//sortear  100 numeros e contar quantos 6 sairam











?>