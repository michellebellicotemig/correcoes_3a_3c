<?php
$contMenor = 0;
$maior = -1;

echo "<h3>Questao 03</h3>";

// Sortear 5 valores referentes a notas de alunos
for($i = 1; $i <= 5; $i++){ //1, 2, 3, 4, 5
    $notas = rand(0, 30);
    // Imprimir quais foram as notas sorteadas
    echo "Nota " . $i . " = " . $notas . "<br>";
    // Contar quantas notas são menores do que 15
    if($notas < 15){
        $contMenor++;
    }
    // Ver qual é a maior nota
    if($notas > $maior){
        $maior = $notas;
    }
}
echo $contMenor . " notas ficaram abaixo de 15 <br>";
echo "A maior nota foi " . $maior . "<br>";

?>