<?php
$contSeis = 0;

echo "<h3>Questao 04</h3>";

for($i = 1; $i <= 100; $i++){ // 1, 2, 3, ..., 99, 100
    $valores = rand(1, 6);
    // Testar se o valor sorteado é igual a 6. Se sim ele conta
    if($valores == 6){
        $contSeis++;
    }
}
echo "O valor 6 foi adivinhado " . $contSeis . " vezes.";

?>