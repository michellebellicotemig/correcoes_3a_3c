<?php
$cont = 0;
$menornota= 15;
$n1 = random_int(0,60);
$n2 = random_int(0,60);
$n3 = random_int(0,60);
$n4 = random_int(0,60);
$n5 = random_int(0,60);
$maior = max($n1, $n2,$n3,$n4,$n5);

echo"A maior nota foi: $maior";

while(cont > 6 ){

    $nota=rand(0,60);

    if ($nota < $menornota){

        $menornota=$nota;
    }

    echo"$nota";
    $cont ++;

}
    echo "A menor nota foi  =". $menornota."<br>" ;