<?php


$i = 0; $soma = 0; $somav = 0;
for ($i = 0; $i <= 2; $i++)
{
     $inteiro = rand(1, 6);
    $soma = $soma + $inteiro;
}
echo "A soma dos valores sorteados é:{$soma} ";
echo "<br>";
if ($soma > 5)
{
    echo" Você deverá escolher qual jogador perderá uma rodada.";
    echo "<br>";
}
else if ($soma == 5)
{
    echo "Compre uma nova carta";
    echo "<br>";
}
else if ($soma < 5)
{
    echo "Decida o destino do jogador à direita.";
}
?>