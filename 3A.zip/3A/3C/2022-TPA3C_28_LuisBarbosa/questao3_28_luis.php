<?php
header('Content-Type: text/html; charset=utf-8');
    $dados = [];
     
    for ($i=0; $i < 3; $i++) { 
        $dados[] = random_int(1,6);
    }

    $msg = "";
    if(array_sum($dados) < 5){
        $msg = "Decida o destino do jogador à direita"; 
    }
    elseif(array_sum($dados) > 5) {
        $msg = "Escolha o jogador que perderá uma rodada."; 
    }
    else {
        $msg = "Compre uma nova carta"; 
    }

    echo "Os dados foram jogados e a sorte lançada. A soma dos valores sorteados é ".array_sum($dados)." <br> $msg";
?>