<?php
    header('Content-Type: text/html; charset=utf-8');
    $escolido = random_int(1,100);
    $dados = [];
    $vezes = 0;
     
    for ($i=0; $i < 100; $i++) { 
        $dados[] = random_int(1,100);
    }

    foreach ($dados as $num) {
        if($escolido == $num){
            $vezes++;
        }
    }

    if($vezes == 0){
        echo "O valor $escolido foi adivinhado nem uma vezes.";
    }
    else {
        echo "O valor $escolido foi adivinhado $vezes vezes.";
    }

?>