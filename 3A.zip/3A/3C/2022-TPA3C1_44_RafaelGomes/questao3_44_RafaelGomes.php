<?php

$i=0;
$soma = 0;


while ($i<3)
{
    $ale=rand(1,6);
    $soma+=$ale;
    $i++;

}
echo "Os dados foram jogados e a sorte lancada. A soma dos valores sorteados e: ".$soma."<br>";
if ($soma>5)
{
    echo "Decida o destino do jogador a direita<br>";
}
if ($soma==5)
{
    echo "Compre uma nova carta<br>";
}
else if($soma<5){
    echo "Escolha o jogador que perdera uma rodada.<br>";
}




?>