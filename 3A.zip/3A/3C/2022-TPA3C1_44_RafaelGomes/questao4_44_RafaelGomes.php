<?php
$i=0;
$cont=0;
$soma=0;


for ($i=0;$i<5;$i++)
{
    $ale=rand(1,100);
    echo $ale."<br>";
    $soma+=$i;
    if ($ale==6)
    {
        $cont++;
    }
}

echo "O valor 6 foi adivinhado ".$cont." vezes";




?>
