<?php

echo"Questao 03";

$soma = 0;


for ($i = 0; $i <=5; $i++)
{
    $soma = $soma + $i;
    
    if ($soma<5)
{
    echo"<br/> Decida o destino do jogador a direita";
}
elseif ($soma==5)
{
    echo"<br/> Compre uma nova carta.";
}
elseif ($soma>5)
{
    echo"<br/>Escolha o jogador que perdera uma rodada.";
}

if($i = 1 || $i = 2 || $i = 5)
{
    echo"<br/>Os dados foram jogados e a sorte lancada. A soma dos valores sorteados eh 8 e
         voce devera escolher qual jogador perdera uma rodada.";
}
}


?>
