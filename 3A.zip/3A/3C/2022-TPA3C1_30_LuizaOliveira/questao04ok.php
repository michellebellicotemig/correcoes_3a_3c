<?php


$cont = 0;

for ($i = 0; $i <= 99; $i++)
{
    if($i = 6)
    {
        $cont++;
    }
}
    echo"O valor 6 foi adivinhado 3 vezes" . $cont++;
?>