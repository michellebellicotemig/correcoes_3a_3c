<?php
header('Content-type: text/html; charset=utf-8');

$qtd6 = 0;

for($x = 0;$x < 100;$x++)
{
    $num[$x] = random_int(1,100);

    if($num{$x} == 6)
    {
        $qtd6++;
    }

}
// var_dump($num);
echo("O valor 6 foi advinhado: " . $qtd6 . " vezes");

?>