<?php
header('Content-type: text/html; charset=utf-8');

$menor15 = 0;
$maior = -20;

for($x = 0;$x < 5;$x++)
{
    $num[$x] = random_int(0,30);

    if($num{$x} < 15)
    {
        $menor15++;
    }

    if($num[$x] > $maior){
        $maior = $num[$x];
    }
}

//var_dump($num);
echo("A quantidade de notas abaixo de 15 foi/é: " . $menor15);
echo("<br>");
echo("A maior nota sorteada foi: " . $maior);

?>