<html>
<?php

$notas = 0;
$cont = 0;


for ($cont =1; $cont<=20; $cont++){
    $num = random_int(0,20);

    {if($num<=15){
        echo("A quantidade de notas abaixo de 15 é:" . $num);
} else {
    echo("Não houve notas abaixo de 15");
}

?>
</html>