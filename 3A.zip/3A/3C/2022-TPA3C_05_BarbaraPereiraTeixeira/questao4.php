<html>
<?php

$num = 0;

while ($num>=0 && $num<=6){
    if($num = 6){
       echo("O número 6 foi repetido" . $num . "vezes");
    }
    $num++;

?>
</html>