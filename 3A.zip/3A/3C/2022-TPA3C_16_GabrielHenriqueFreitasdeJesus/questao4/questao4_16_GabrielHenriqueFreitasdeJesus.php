<?php    
$valor = rand(1/100);
$repeticoes = 6;
 echo $valor;

if($valor == $repeticoes){
   echo "Valor 6 foi adivinhado" . $repeticoes . "vezes";
} else {
    echo "Valor 6 nao foi sorteado";
}

?>