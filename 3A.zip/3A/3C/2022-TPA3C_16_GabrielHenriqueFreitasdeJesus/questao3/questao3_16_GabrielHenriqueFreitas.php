<?php 
$valor1 = 1;
$valor2 = 4;
$valor3 = 3;
$somavalores = $valor1 + $valor2 + $valor3;

 echo  "<p>A soma total e de:" . $somavalores; 


if($valor1 + $valor2 + $valor3 < 5){
 echo "Decida o Destino do jogador a direita.";
} else if ($valor1 + $valor2 + $valor3 == 5 ) {
    echo "Compre uma nova carta";
} else if ($valor1 + $valor2 + $valor3 > 5){
    echo "Escolha o jogador que perdera uma rodada";
} else {
    echo "Declare um valor";
}



?>