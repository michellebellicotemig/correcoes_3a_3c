<?php

//RAND() --> rand(0,10);    aleatorio;

//variaveis;
$cont = 0;
$notas = rand(0,31);
$maiornota = 0;
$soma = 0;
$qntdMenor15 = 0;

while($cont < 3){
    $i = rand(1,30);
    $soma += $i;
    $cont++;

    if ($notas < 15){
        $qntdMenor15++;
    }
}

echo ($qntdMenor15. "Nota é menor que 15.");

echo($nota."</br>");



