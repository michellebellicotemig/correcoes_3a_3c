<?php 

 // variaveis
	$soma = 0;
	$media = 0;

// USANDO LAÇO DE REPETIÇÃO;

for($i =0; $i<=4; $i++){
	if($i % 2 == 0){
		$soma = $soma + $i;
	}
}
