<?php

$cont = 0;
$menorValor = 100;
$maiorValor = -100;
$soma = 0;
$quantMenor15 = 0;

while($cont < 6)
{
	$valorentrada = rand(1,6);

	if($temperatura < $menorValor)
	{
		$menorValor = $valorentrada;
	}
	if($valorentrada> $maiorValor)
	{
		$maiorValor = $valorentrada;
	}
	if($temperatura<15)
	{
	 	$soma += $valorentrada;
		$quantMenor15++;
	}
	echo($valorentrada );
	$cont++;
}
