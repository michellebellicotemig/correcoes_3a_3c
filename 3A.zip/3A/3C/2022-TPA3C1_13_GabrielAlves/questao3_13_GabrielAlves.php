<?php

echo("Questao 03");

$soma = 0;



for ($i = 0; $i <=5;$i++){
 if($i % 2 == 0){
 $soma = $soma + $i;

 }	

}


if($soma > 15){
    echo('<br/>A maior nota foi 30.5');
    
    }else{
        echo('<br/>Uma nota ficou abaixo de 15');
    }   

?>