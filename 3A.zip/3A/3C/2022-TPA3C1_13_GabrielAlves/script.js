<div class="alert alert-success" role="alert">
o usuário não pode ser excluído
</div>