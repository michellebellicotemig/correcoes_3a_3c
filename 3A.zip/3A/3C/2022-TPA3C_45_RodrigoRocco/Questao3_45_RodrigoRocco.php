<?php

$cont = 0;
$maiorvalor = -999;

for($i = 0; $i <= 4; $i++){
    $valor = rand(1, 30);
    if($valor < 15){
        $cont++;
    }
    if($valor > $maiorvalor){
        $maiorvalor = $valor;
    }
}
echo $cont . " notas ficaram abaixo de 15 </br>";

echo "A maior nota e " . $maiorvalor; 




?>