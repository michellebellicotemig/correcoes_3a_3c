<?php

$contar = 0;
$somar = 0;
$i = 0;

for($contar = 0; $contar < 5; $contar++){
$random = rand(1, 100);
echo $random. "<br>";
$somar += $contar;
if($random == 6){
    $i++;
  }
}

echo "O valor 6 foi adivinhado " . $i . " vezes";





?>