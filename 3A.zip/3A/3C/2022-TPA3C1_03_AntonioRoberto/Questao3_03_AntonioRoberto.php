<php
$nota = 0;

if($nota < 15) {
    echo($nota . " foi menor do que 15, portanto é uma nota baixa");
}
else {
    echo($nota . " foi maior do que 15, portanto é uma nota alta");
}

?>