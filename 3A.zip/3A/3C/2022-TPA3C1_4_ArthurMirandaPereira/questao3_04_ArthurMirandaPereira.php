<?php
$dado1 = 1;    
$dado2 = 2;
$dado3 = 4;
$soma = $dado1 + $dado2 + $dado3;

if($soma < 5){
    echo "A soma foi igual a : ". $soma. ", logo siga a direita";
}else if($soma == 5){
    echo "A soma foi igual a : ". $soma. ", logo compre uma nova carta";
}else if($soma > 5){
    echo "A soma foi igual a : ". $soma. ", logo escolha um jogador para perder uma rodada";
}

?>
