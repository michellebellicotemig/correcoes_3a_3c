<?php
//Eu esqueci o comando para random no php :(
$num1 = 1;
$num2 = 6;
$num3 = 7;
$num4 = 8;
$num5 = 1;
$num6 = 6;
$num7 = 1;
$num8 = 6;
$num9 = 8;
$num10 = 11;
$num11 = 21;
$i = 0;
$seis = 0;

while ($i <= 11){
    if($i == 6){
        $seis++;
    }
}
echo "Dos 11 números, ". $seis. "são 6";

?>