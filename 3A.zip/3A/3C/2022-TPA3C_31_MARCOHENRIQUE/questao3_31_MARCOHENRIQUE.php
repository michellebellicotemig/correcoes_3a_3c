<?php 
///Questao 3
echo "QUESTAO 3<br>";
echo "<br>BOLETIM<br>";
///declarando variaveis
$maior = 0;
$i = 0;
$notas = 0;
$menores = 0;

///estrutura de repeticao "for"
for($i = 0; $i <=4; $i++){
    //gerando numero aleatorio
    $aleatorio = rand(5, 30);
    ///exibindo na tela do usuario
    echo "Aluno {$i}: Nota {$aleatorio}<br>";

    ///notas menores que 15
    if($aleatorio < 15){
        $menores++;
    }
    ///maior nota
    if($aleatorio > $maior){
        $maior = $aleatorio;
    }
}
echo "<br>";
echo "{$menores} nota/s ficou abaixo de 15<br>";
echo "A maior nota foi {$maior}";



?>