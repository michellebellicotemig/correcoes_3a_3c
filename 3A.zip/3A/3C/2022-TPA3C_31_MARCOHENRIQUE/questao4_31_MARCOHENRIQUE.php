<?php
///Questao 4
echo "QUESTAO 4<br>";

///declarando variaveis
$i = 0;
$valor6 = 0;

///estrutura de repeticao
for($i = 0; $i <= 99; $i++){
    ///gerando 100 numeros aleatorios
    $aleatorio = rand(1, 100);
    ///exibindo na tela do usuario
    echo "Numero{$i}: {$aleatorio}<br>";

    ///verificando numeros iguais a 6
    if($aleatorio == 6){
        ///numeros de 6 encontrados
        $valor6++;
    }
}

///saida de resultado na tela do usuario
echo "O valor 6 foi adivinhado: {$valor6} vezes";




?>