<?php

$dado1 = range(1,6);
$dado2 = range(1,6);
$dado3 = range(1,6);
$soma = $dado1 + $dado2 + $dado3;



if( $soma < 5)
{
    echo" Decida o destino do jogador a direita.";
}

if( $soma == 5)
{
    echo"Compre uma nova carta";
}

if($soma > 5 )
{
    echo"Escolha o jogador que perdera uma rodada.";
}
?>