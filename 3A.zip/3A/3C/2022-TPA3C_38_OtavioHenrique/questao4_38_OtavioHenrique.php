<?php


$numero = 0;
$numero2 = 0;

for($i = 0; $i < 100; $i++)
{
  $numero = rand(0,100);

  if($numero == 6)
  {
      $numero += 1;
      echo" foram encontrados " .$numero2."valores = 6";
  }
}
?>
