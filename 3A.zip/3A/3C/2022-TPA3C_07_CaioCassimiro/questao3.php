<?php
    $v1= 74;
    $v2 = 7;
    $v3 = 4;
    $v4 = 16;
    $v5 = 2;
    $maior = '';


    if ($v1 < 15 || $v2 < 15 || $v3 < 15 || $v4 < 15 || $v5 < 15) {
         echo("menores que 15 ");
    }


    if ($v1 > $v2 && $v1 > $v3 && $v1 > $v4 && $v1 > $v5) {
        echo("maior valor e ".$v1);
    } elseif ($v2 > $v1 && $v2 > $v3 && $v2 > $v4 && $v2 > $v5) {
        echo("maior valor e ".$v2);
    } elseif ($v3 > $v1 && $v3 > $v2 && $v3 > $v4 && $v3 > $v5) {
        echo("maior valor e ".$v3);
    }elseif ($v4 > $v1 && $v4 > $v2 && $v4 > $v3 && $v4 > $v5) {
        echo("maior valor e ".$v4);
    }elseif ($v5 > $v1 && $v5 > $v2 && $v5 > $v3 && $v5 > $v4) {
        echo("maior valor e ".$v5);
    }

    //'s' abreviacao para sorteado

    $s1 = 12;
    $s2 = 22;
    $s3 = 18;
    $s4 = 30.5;
    $s5 = 5;
    $s6 = 9;

    if ($s1 < 15 || $s2 < 15 || $s3 < 15 || $s4 < 15 || $s5 < 15|| $s6 < 15) {
        echo("Uma nota menor que 15 ");
   }

   if ($s1 > $s2 && $s1 > $s3 && $s1 > $s4 && $s1 > $s5 && $s1 > $s6) {
    echo("maior nota e ".$s1);
} elseif ($s2 > $s1 && $s2 > $s3 && $s2 > $s4 && $s2 > $s5 && $s2 > $s6) {
    echo("maior nota e ".$s2);
} elseif ($s3 > $s1 && $s3 > $s2 && $s3 > $s4 && $s3 > $s5 && $s3 > $s6) {
    echo("maior nota e ".$s3);
}elseif ($s4 > $s1 && $s4 > $s2 && $s4 > $s3 && $s4 > $s5 && $s4 > $s6) {
    echo("maior nota e ".$s4);
}elseif ($s5 > $s1 && $s5 > $s2 && $s5 > $s3 && $s5 > $s4 && $s5 > $s6) {
    echo("maior nota e ".$s5);
}elseif ($s6 > $s1 && $s6 > $s2 && $s6 > $s3 && $s6 > $s4 && $s6 > $s5) {
    echo("maior nota e ".$s6);
}

    
?>