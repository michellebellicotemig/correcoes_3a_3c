<?php  
    $rptNum = '';

    for ($i=0; $i < 101 ; $i++) { 
        if ($i = 6) {
            $aleatorio = rand(1,100);
            $rptNum++;
            $rptNum == 3;
           echo(" A quantidade de numeros repetida e ".$rptNum);

        }
    }



?>