<!DOCTYPE html>
<html>
<body>
<h1 style="background-color:Pink;" >Questão 03</h1>
<?php
header('Content-Type: text/html; charset=utf-8');
$cont=0;
for($i =0; $i<=99; $i++){
    $aleot= rand(1,100);
    if($aleot== 6)
    {
        $cont++;
    

    }

}
echo ("O número 6 apreceu esse tanto de vez ".$cont);