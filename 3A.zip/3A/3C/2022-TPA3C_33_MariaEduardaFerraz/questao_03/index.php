<!DOCTYPE html>
<html>
<body>
<h1 style="background-color:Pink;" >Questão 03</h1>
<?php
header('Content-Type: text/html; charset=utf-8');

$nota = rand(0,30);
$nota15= 0;
$n=0;
for ($i=0; $i<5;$i++)
{   $nota = rand(0,30);
   if ($nota<15)
   {
      $nota15++;
   }
}

$nota15= $nota15 + $n;
echo ("As notas que foram acima de 15 são: ".$nota15);

?> 